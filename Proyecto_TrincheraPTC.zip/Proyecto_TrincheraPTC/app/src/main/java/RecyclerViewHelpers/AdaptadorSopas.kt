package RecyclerViewHelpers

class AdaptadorSopas {
}